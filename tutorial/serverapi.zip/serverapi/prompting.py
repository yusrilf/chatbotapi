class openAI():
    
    def __init__(self,prompt,created=None):
    
        self.prompt = prompt


